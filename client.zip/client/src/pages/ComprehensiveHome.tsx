import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Scale3D, ChevronLeft, ChevronRight, Printer, Download, FileText, Sheet, Plus, Trash2 } from 'lucide-react';
import { calculateComprehensiveInheritance, type Heir, type ComprehensiveInput } from '@/lib/comprehensiveInheritance';
import { exportToPDF, exportToExcel, exportToCSV } from '@/lib/exportFunctions';

type School = 'hanafi' | 'maliki' | 'shafei' | 'hanbali' | 'ismaili';

const schoolNames: Record<School, string> = {
  hanafi: 'الحنفية',
  maliki: 'المالكية',
  shafei: 'الشافعية',
  hanbali: 'الحنابلة',
  ismaili: 'الإسماعيلية',
};

export default function ComprehensiveHome() {
  const [currentStep, setCurrentStep] = useState(1);
  const [school, setSchool] = useState<School>('hanafi');
  const [gender, setGender] = useState('male');
  const [deceasedName, setDeceasedName] = useState('');
  const [totalMoney, setTotalMoney] = useState('');
  const [totalMeters, setTotalMeters] = useState('');
  
  // Heirs data
  const [heirsData, setHeirsData] = useState({
    spouses: 0,
    father: false,
    mother: false,
    sons: 0,
    daughters: 0,
    paternal_grandfather: false,
    paternal_grandmother: false,
    maternal_grandfather: false,
    maternal_grandmother: false,
    full_brothers: 0,
    full_sisters: 0,
    half_brothers_paternal: 0,
    half_sisters_paternal: 0,
    half_brothers_maternal: 0,
    half_sisters_maternal: 0,
    paternal_uncles: 0,
    paternal_aunts: 0,
    maternal_uncles: 0,
    maternal_aunts: 0,
    maternal_uncles_from_mother: 0,
    maternal_aunts_from_mother: 0,
    grandsons: 0,
    granddaughters: 0,
    great_grandsons: 0,
    great_granddaughters: 0,
  });

  const [heirNames, setHeirNames] = useState<Record<string, string>>({});
  const [heirReligions, setHeirReligions] = useState<Record<string, string>>({});
  const [results, setResults] = useState<Heir[]>([]);

  const calculateShares = () => {
    const input: ComprehensiveInput = {
      gender: gender as 'male' | 'female',
      deceasedName,
      totalMoney: parseFloat(totalMoney) || 0,
      totalMeters: parseFloat(totalMeters) || 0,
      heirs: heirsData,
      school,
      heirNames,
    };

    const newResults = calculateComprehensiveInheritance(input);
    setResults(newResults);
    setCurrentStep(3);
  };

  const handleNameChange = (key: string, value: string) => {
    setHeirNames(prev => ({ ...prev, [key]: value }));
  };

  const handleReligionChange = (key: string, value: string) => {
    setHeirReligions(prev => ({ ...prev, [key]: value }));
  };

  const handleHeirCountChange = (key: string, value: string) => {
    const numValue = parseInt(value) || 0;
    setHeirsData(prev => ({ ...prev, [key]: numValue }));
  };

  const handleBooleanChange = (key: string, value: boolean) => {
    setHeirsData(prev => ({ ...prev, [key]: value }));
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportPDF = () => {
    const exportData = {
      deceasedName,
      school,
      totalMoney: parseFloat(totalMoney) || 0,
      totalMeters: parseFloat(totalMeters) || 0,
      heirs: results,
      exportDate: new Date().toLocaleDateString('ar-SA'),
    };
    exportToPDF(exportData);
  };

  const handleExportExcel = () => {
    const exportData = {
      deceasedName,
      school,
      totalMoney: parseFloat(totalMoney) || 0,
      totalMeters: parseFloat(totalMeters) || 0,
      heirs: results,
      exportDate: new Date().toLocaleDateString('ar-SA'),
    };
    exportToExcel(exportData);
  };

  const handleExportCSV = () => {
    const exportData = {
      deceasedName,
      school,
      totalMoney: parseFloat(totalMoney) || 0,
      totalMeters: parseFloat(totalMeters) || 0,
      heirs: results,
      exportDate: new Date().toLocaleDateString('ar-SA'),
    };
    exportToCSV(exportData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-br from-green-600 to-green-800 p-4 rounded-2xl shadow-lg">
              <Scale3D className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">نظام تقسيم الميراث الشرعي الشامل</h1>
          <p className="text-gray-600 text-lg">حساب دقيق لجميع أنواع الورثة وفق أحكام الشريعة الإسلامية</p>
        </div>

        {/* Step Navigation */}
        <div className="mb-8">
          <div className="flex gap-4 justify-center">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center gap-4">
                <button
                  onClick={() => step < currentStep && setCurrentStep(step)}
                  className={`w-12 h-12 rounded-full font-bold text-lg transition-all ${
                    step === currentStep
                      ? 'bg-green-600 text-white shadow-lg scale-110'
                      : step < currentStep
                      ? 'bg-green-100 text-green-700 cursor-pointer hover:bg-green-200'
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {step}
                </button>
                {step < 3 && (
                  <div className={`w-12 h-1 ${step < currentStep ? 'bg-green-600' : 'bg-gray-300'}`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-4 text-sm font-semibold text-gray-700">
            <span>البيانات الأساسية</span>
            <span>أسماء الورثة</span>
            <span>النتائج</span>
          </div>
        </div>

        {/* Step 1: Basic Data */}
        {currentStep === 1 && (
          <Card className="p-8 shadow-lg border-0">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">خطوة 1: البيانات الأساسية</h2>
            
            <div className="space-y-6">
              {/* School Selection */}
              <div>
                <Label className="text-base font-semibold text-gray-700 mb-3 block">اختر المذهب الشرعي:</Label>
                <Select value={school} onValueChange={(value) => setSchool(value as School)}>
                  <SelectTrigger className="w-full text-right">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hanafi">الحنفية</SelectItem>
                    <SelectItem value="maliki">المالكية</SelectItem>
                    <SelectItem value="shafei">الشافعية</SelectItem>
                    <SelectItem value="hanbali">الحنابلة</SelectItem>
                    <SelectItem value="ismaili">الإسماعيلية</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Gender Selection */}
              <div>
                <Label className="text-base font-semibold text-gray-700 mb-3 block">نوع المتوفى:</Label>
                <RadioGroup value={gender} onValueChange={setGender} className="flex gap-6">
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="male" id="male" />
                    <Label htmlFor="male" className="cursor-pointer text-gray-700">ذكر</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="female" id="female" />
                    <Label htmlFor="female" className="cursor-pointer text-gray-700">أنثى</Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Deceased Name */}
              <div>
                <Label htmlFor="name" className="text-base font-semibold text-gray-700 mb-2 block">اسم المتوفى:</Label>
                <Input
                  id="name"
                  placeholder="أدخل اسم المتوفى"
                  value={deceasedName}
                  onChange={(e) => setDeceasedName(e.target.value)}
                  className="text-right"
                />
              </div>

              {/* Money and Meters */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="money" className="text-base font-semibold text-gray-700 mb-2 block">مبلغ التركة (ريال):</Label>
                  <Input
                    id="money"
                    type="number"
                    placeholder="0"
                    value={totalMoney}
                    onChange={(e) => setTotalMoney(e.target.value)}
                    className="text-right"
                  />
                </div>
                <div>
                  <Label htmlFor="meters" className="text-base font-semibold text-gray-700 mb-2 block">إجمالي الأمتار:</Label>
                  <Input
                    id="meters"
                    type="number"
                    placeholder="0"
                    value={totalMeters}
                    onChange={(e) => setTotalMeters(e.target.value)}
                    className="text-right"
                  />
                </div>
              </div>

              {/* Heirs Selection - Comprehensive */}
              <div className="space-y-6">
                <div className="bg-gradient-to-br from-green-50 to-blue-50 p-6 rounded-lg border border-green-200">
                  <h3 className="font-bold text-gray-900 mb-4 text-lg">الورثة الأساسيون:</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-700 mb-2 block">{gender === 'male' ? 'الزوجات' : 'الزوج'}:</Label>
                      <Input
                        type="number"
                        min="0"
                        value={heirsData.spouses}
                        onChange={(e) => handleHeirCountChange('spouses', e.target.value)}
                        className="text-right"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">الأب:</Label>
                      <Select value={heirsData.father ? '1' : '0'} onValueChange={(v) => handleBooleanChange('father', v === '1')}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">لا</SelectItem>
                          <SelectItem value="1">نعم</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">الأم:</Label>
                      <Select value={heirsData.mother ? '1' : '0'} onValueChange={(v) => handleBooleanChange('mother', v === '1')}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">لا</SelectItem>
                          <SelectItem value="1">نعم</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">الأبناء:</Label>
                      <Input
                        type="number"
                        min="0"
                        value={heirsData.sons}
                        onChange={(e) => handleHeirCountChange('sons', e.target.value)}
                        className="text-right"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">البنات:</Label>
                      <Input
                        type="number"
                        min="0"
                        value={heirsData.daughters}
                        onChange={(e) => handleHeirCountChange('daughters', e.target.value)}
                        className="text-right"
                      />
                    </div>
                  </div>
                </div>

                {/* Grandparents */}
                <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-6 rounded-lg border border-blue-200">
                  <h3 className="font-bold text-gray-900 mb-4 text-lg">الأجداد والجدات:</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-700 mb-2 block">جد الأب:</Label>
                      <Select value={heirsData.paternal_grandfather ? '1' : '0'} onValueChange={(v) => handleBooleanChange('paternal_grandfather', v === '1')}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">لا</SelectItem>
                          <SelectItem value="1">نعم</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">جدة الأب:</Label>
                      <Select value={heirsData.paternal_grandmother ? '1' : '0'} onValueChange={(v) => handleBooleanChange('paternal_grandmother', v === '1')}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">لا</SelectItem>
                          <SelectItem value="1">نعم</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">جد الأم:</Label>
                      <Select value={heirsData.maternal_grandfather ? '1' : '0'} onValueChange={(v) => handleBooleanChange('maternal_grandfather', v === '1')}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">لا</SelectItem>
                          <SelectItem value="1">نعم</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">جدة الأم:</Label>
                      <Select value={heirsData.maternal_grandmother ? '1' : '0'} onValueChange={(v) => handleBooleanChange('maternal_grandmother', v === '1')}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">لا</SelectItem>
                          <SelectItem value="1">نعم</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Siblings */}
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-lg border border-purple-200">
                  <h3 className="font-bold text-gray-900 mb-4 text-lg">الإخوة والأخوات:</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-700 mb-2 block">الإخوة الشقيقون:</Label>
                      <Input
                        type="number"
                        min="0"
                        value={heirsData.full_brothers}
                        onChange={(e) => handleHeirCountChange('full_brothers', e.target.value)}
                        className="text-right"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">الأخوات الشقيقات:</Label>
                      <Input
                        type="number"
                        min="0"
                        value={heirsData.full_sisters}
                        onChange={(e) => handleHeirCountChange('full_sisters', e.target.value)}
                        className="text-right"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">الإخوة من الأب:</Label>
                      <Input
                        type="number"
                        min="0"
                        value={heirsData.half_brothers_paternal}
                        onChange={(e) => handleHeirCountChange('half_brothers_paternal', e.target.value)}
                        className="text-right"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">الأخوات من الأب:</Label>
                      <Input
                        type="number"
                        min="0"
                        value={heirsData.half_sisters_paternal}
                        onChange={(e) => handleHeirCountChange('half_sisters_paternal', e.target.value)}
                        className="text-right"
                      />
                    </div>
                  </div>
                </div>

                {/* Uncles and Aunts */}
                <div className="bg-gradient-to-br from-pink-50 to-red-50 p-6 rounded-lg border border-pink-200">
                  <h3 className="font-bold text-gray-900 mb-4 text-lg">الأعمام والعمات:</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-700 mb-2 block">الأعمام:</Label>
                      <Input
                        type="number"
                        min="0"
                        value={heirsData.paternal_uncles}
                        onChange={(e) => handleHeirCountChange('paternal_uncles', e.target.value)}
                        className="text-right"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-2 block">العمات:</Label>
                      <Input
                        type="number"
                        min="0"
                        value={heirsData.paternal_aunts}
                        onChange={(e) => handleHeirCountChange('paternal_aunts', e.target.value)}
                        className="text-right"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Navigation Buttons */}
              <div className="flex justify-between gap-4 pt-6">
                <Button
                  onClick={() => setCurrentStep(2)}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white py-6 text-lg font-bold rounded-lg transition-all"
                >
                  التالي
                  <ChevronLeft className="w-5 h-5 mr-2" />
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Step 2: Names */}
        {currentStep === 2 && (
          <Card className="p-8 shadow-lg border-0">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">خطوة 2: أسماء الورثة</h2>
            <p className="text-gray-600 mb-6">المذهب المختار: <span className="font-bold text-green-700">{schoolNames[school]}</span></p>
            
            <div className="space-y-6">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-green-50 border-b-2 border-green-200">
                      <TableHead className="text-right text-gray-900 font-bold">الديانة</TableHead>
                      <TableHead className="text-right text-gray-900 font-bold">الاسم الكامل</TableHead>
                      <TableHead className="text-right text-gray-900 font-bold">الصلة</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* Spouses */}
                    {heirsData.spouses > 0 && Array.from({ length: heirsData.spouses }).map((_, i) => (
                      <TableRow key={`spouse-${i}`} className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell>
                          <Select value={heirReligions[`spouse-${i}`] || 'muslim'} onValueChange={(v) => handleReligionChange(`spouse-${i}`, v)}>
                            <SelectTrigger className="text-right text-sm">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="muslim">مسلم</SelectItem>
                              <SelectItem value="non-muslim">غير مسلم</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames[`spouse-${i}`] || ''}
                            onChange={(e) => handleNameChange(`spouse-${i}`, e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                        <TableCell className="text-gray-700 font-semibold">{gender === 'male' ? 'زوجة' : 'زوج'}</TableCell>
                      </TableRow>
                    ))}

                    {/* Father */}
                    {heirsData.father && (
                      <TableRow className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell>
                          <Select value={heirReligions['father'] || 'muslim'} onValueChange={(v) => handleReligionChange('father', v)}>
                            <SelectTrigger className="text-right text-sm">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="muslim">مسلم</SelectItem>
                              <SelectItem value="non-muslim">غير مسلم</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames['father'] || ''}
                            onChange={(e) => handleNameChange('father', e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                        <TableCell className="text-gray-700 font-semibold">أب</TableCell>
                      </TableRow>
                    )}

                    {/* Mother */}
                    {heirsData.mother && (
                      <TableRow className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell>
                          <Select value={heirReligions['mother'] || 'muslim'} onValueChange={(v) => handleReligionChange('mother', v)}>
                            <SelectTrigger className="text-right text-sm">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="muslim">مسلم</SelectItem>
                              <SelectItem value="non-muslim">غير مسلم</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames['mother'] || ''}
                            onChange={(e) => handleNameChange('mother', e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                        <TableCell className="text-gray-700 font-semibold">أم</TableCell>
                      </TableRow>
                    )}

                    {/* Sons */}
                    {heirsData.sons > 0 && Array.from({ length: heirsData.sons }).map((_, i) => (
                      <TableRow key={`son-${i}`} className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">ابن</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames[`son-${i}`] || ''}
                            onChange={(e) => handleNameChange(`son-${i}`, e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    ))}

                    {/* Daughters */}
                    {heirsData.daughters > 0 && Array.from({ length: heirsData.daughters }).map((_, i) => (
                      <TableRow key={`daughter-${i}`} className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">بنت</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames[`daughter-${i}`] || ''}
                            onChange={(e) => handleNameChange(`daughter-${i}`, e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    ))}

                    {/* Paternal Grandfather */}
                    {heirsData.paternal_grandfather && (
                      <TableRow className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">جد أب</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames['paternal-grandfather'] || ''}
                            onChange={(e) => handleNameChange('paternal-grandfather', e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    )}

                    {/* Paternal Grandmother */}
                    {heirsData.paternal_grandmother && (
                      <TableRow className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">جدة أب</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames['paternal-grandmother'] || ''}
                            onChange={(e) => handleNameChange('paternal-grandmother', e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    )}

                    {/* Maternal Grandfather */}
                    {heirsData.maternal_grandfather && (
                      <TableRow className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">جد أم</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames['maternal-grandfather'] || ''}
                            onChange={(e) => handleNameChange('maternal-grandfather', e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    )}

                    {/* Maternal Grandmother */}
                    {heirsData.maternal_grandmother && (
                      <TableRow className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">جدة أم</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames['maternal-grandmother'] || ''}
                            onChange={(e) => handleNameChange('maternal-grandmother', e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    )}

                    {/* Full Brothers */}
                    {heirsData.full_brothers > 0 && Array.from({ length: heirsData.full_brothers }).map((_, i) => (
                      <TableRow key={`full-brother-${i}`} className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">أخ شقيق</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames[`full-brother-${i}`] || ''}
                            onChange={(e) => handleNameChange(`full-brother-${i}`, e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    ))}

                    {/* Full Sisters */}
                    {heirsData.full_sisters > 0 && Array.from({ length: heirsData.full_sisters }).map((_, i) => (
                      <TableRow key={`full-sister-${i}`} className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">أخت شقيقة</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames[`full-sister-${i}`] || ''}
                            onChange={(e) => handleNameChange(`full-sister-${i}`, e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    ))}

                    {/* Paternal Uncles */}
                    {heirsData.paternal_uncles > 0 && Array.from({ length: heirsData.paternal_uncles }).map((_, i) => (
                      <TableRow key={`paternal-uncle-${i}`} className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">عم</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames[`paternal-uncle-${i}`] || ''}
                            onChange={(e) => handleNameChange(`paternal-uncle-${i}`, e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    ))}

                    {/* Paternal Aunts */}
                    {heirsData.paternal_aunts > 0 && Array.from({ length: heirsData.paternal_aunts }).map((_, i) => (
                      <TableRow key={`paternal-aunt-${i}`} className="border-b border-gray-200 hover:bg-gray-50">
                        <TableCell className="text-gray-700 font-semibold">عمة</TableCell>
                        <TableCell>
                          <Input
                            placeholder="الاسم الكامل"
                            value={heirNames[`paternal-aunt-${i}`] || ''}
                            onChange={(e) => handleNameChange(`paternal-aunt-${i}`, e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Navigation Buttons */}
              <div className="flex justify-between gap-4 pt-6">
                <Button
                  onClick={() => setCurrentStep(1)}
                  variant="outline"
                  className="flex-1 py-6 text-lg font-bold rounded-lg"
                >
                  <ChevronRight className="w-5 h-5 ml-2" />
                  السابق
                </Button>
                <Button
                  onClick={calculateShares}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white py-6 text-lg font-bold rounded-lg transition-all"
                >
                  عرض النتيجة
                  <ChevronLeft className="w-5 h-5 mr-2" />
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Step 3: Results */}
        {currentStep === 3 && (
          <Card className="p-8 shadow-lg border-0">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">خطوة 3: النتائج</h2>
            <p className="text-gray-600 mb-2">تقسيم الميراث لـ: <span className="font-bold text-green-700">{deceasedName || 'المتوفى'}</span></p>
            <p className="text-gray-600 mb-6">المذهب المختار: <span className="font-bold text-green-700">{schoolNames[school]}</span></p>
            
            <div className="overflow-x-auto mb-6">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gradient-to-r from-green-600 to-green-700 border-0">
                    <TableHead className="text-right text-white font-bold">الصلة</TableHead>
                    <TableHead className="text-right text-white font-bold">الاسم</TableHead>
                    <TableHead className="text-right text-white font-bold">النسبة</TableHead>
                    <TableHead className="text-right text-white font-bold">المال (ريال)</TableHead>
                    <TableHead className="text-right text-white font-bold">المتر</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {results.map((heir, idx) => (
                    <TableRow key={idx} className="border-b border-gray-200 hover:bg-green-50 transition-colors">
                      <TableCell className="text-gray-700 font-semibold">{heir.relation}</TableCell>
                      <TableCell className="text-gray-900 font-medium">{heir.name}</TableCell>
                      <TableCell className="text-green-700 font-bold">{(heir.share * 100).toFixed(2)}%</TableCell>
                      <TableCell className="text-gray-900 font-medium">{heir.money.toFixed(2)}</TableCell>
                      <TableCell className="text-gray-900 font-medium">{heir.meters.toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Summary */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 border-0">
                <p className="text-gray-600 text-sm">إجمالي التركة (مال)</p>
                <p className="text-2xl font-bold text-blue-700">{parseFloat(totalMoney).toFixed(2)} ريال</p>
              </Card>
              <Card className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 border-0">
                <p className="text-gray-600 text-sm">إجمالي التركة (أمتار)</p>
                <p className="text-2xl font-bold text-purple-700">{parseFloat(totalMeters).toFixed(2)} متر</p>
              </Card>
              <Card className="p-4 bg-gradient-to-br from-green-50 to-green-100 border-0">
                <p className="text-gray-600 text-sm">عدد الورثة</p>
                <p className="text-2xl font-bold text-green-700">{results.length}</p>
              </Card>
            </div>

            {/* Export and Navigation Buttons */}
            <div className="space-y-4 pt-6 print:hidden">
              {/* Export Buttons */}
              <div className="grid grid-cols-3 gap-3">
                <Button
                  onClick={handleExportPDF}
                  className="bg-red-600 hover:bg-red-700 text-white py-4 text-base font-bold rounded-lg transition-all flex items-center justify-center gap-2"
                >
                  <FileText className="w-5 h-5" />
                  تصدير PDF
                </Button>
                <Button
                  onClick={handleExportExcel}
                  className="bg-green-600 hover:bg-green-700 text-white py-4 text-base font-bold rounded-lg transition-all flex items-center justify-center gap-2"
                >
                  <Sheet className="w-5 h-5" />
                  تصدير Excel
                </Button>
                <Button
                  onClick={handleExportCSV}
                  className="bg-blue-600 hover:bg-blue-700 text-white py-4 text-base font-bold rounded-lg transition-all flex items-center justify-center gap-2"
                >
                  <Download className="w-5 h-5" />
                  تصدير CSV
                </Button>
              </div>

              {/* Navigation Buttons */}
              <div className="flex justify-between gap-4">
                <Button
                  onClick={() => setCurrentStep(2)}
                  variant="outline"
                  className="flex-1 py-6 text-lg font-bold rounded-lg"
                >
                  <ChevronRight className="w-5 h-5 ml-2" />
                  تعديل
                </Button>
                <Button
                  onClick={handlePrint}
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-6 text-lg font-bold rounded-lg transition-all"
                >
                  <Printer className="w-5 h-5 mr-2" />
                  طباعة
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>

      {/* Print Styles */}
      <style>{`
        @media print {
          body {
            background: white;
          }
          .print\\:hidden {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
}
