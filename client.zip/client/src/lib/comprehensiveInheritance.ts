/**
 * نظام شامل لحساب المواريث الشرعية - يشمل جميع أنواع الورثة
 * Design: نظام الأناقة الإسلامية الحديثة - محرك الحسابات الشامل
 */

export interface Heir {
  id: string;
  relation: string;
  name: string;
  religion: string;
  share: number;
  money: number;
  meters: number;
}

export interface ComprehensiveInput {
  gender: 'male' | 'female';
  deceasedName: string;
  totalMoney: number;
  totalMeters: number;
  heirs: {
    // الورثة الأساسيون
    spouses: number;
    father: boolean;
    mother: boolean;
    sons: number;
    daughters: number;
    // الأجداد والجدات
    paternal_grandfather: boolean;
    paternal_grandmother: boolean;
    maternal_grandfather: boolean;
    maternal_grandmother: boolean;
    // الإخوة والأخوات
    full_brothers: number;
    full_sisters: number;
    half_brothers_paternal: number;
    half_sisters_paternal: number;
    half_brothers_maternal: number;
    half_sisters_maternal: number;
    // الأعمام والعمات
    paternal_uncles: number;
    paternal_aunts: number;
    maternal_uncles: number;
    maternal_aunts: number;
    // الأخوال والخالات
    maternal_uncles_from_mother: number;
    maternal_aunts_from_mother: number;
    // الأحفاد
    grandsons: number;
    granddaughters: number;
    // أبناء الأبناء
    great_grandsons: number;
    great_granddaughters: number;
  };
  school: 'hanafi' | 'maliki' | 'shafei' | 'hanbali' | 'ismaili';
  heirNames: Record<string, string>;
}

// ==================== الحنفية - نظام شامل ====================
export function calculateHanafiComprehensive(input: ComprehensiveInput): Heir[] {
  const results: Heir[] = [];
  const { gender, totalMoney, totalMeters, heirs, heirNames } = input;

  let remainingShare = 1;
  let heirCount = 0;

  // 1. حساب نصيب الزوجات/الزوج
  if (heirs.spouses > 0) {
    let spouseShare = 0;
    const hasChildren = heirs.sons > 0 || heirs.daughters > 0;
    const hasGrandchildren = heirs.grandsons > 0 || heirs.granddaughters > 0;

    if (gender === 'male') {
      spouseShare = hasChildren || hasGrandchildren ? 1 / 8 : 1 / 4;
    } else {
      spouseShare = 1 / 4;
    }

    for (let i = 0; i < heirs.spouses; i++) {
      const name = heirNames[`spouse-${i}`] || `${gender === 'male' ? 'الزوجة' : 'الزوج'} ${i + 1}`;
      results.push({
        id: `spouse-${i}`,
        relation: gender === 'male' ? 'زوجة' : 'زوج',
        name,
        religion: 'مسلم',
        share: spouseShare,
        money: totalMoney * spouseShare,
        meters: totalMeters * spouseShare,
      });
      remainingShare -= spouseShare;
    }
  }

  // 2. حساب نصيب الأب
  if (heirs.father) {
    let fatherShare = 0;
    const hasChildren = heirs.sons > 0 || heirs.daughters > 0;

    if (hasChildren) {
      fatherShare = 1 / 6;
    } else if (heirs.mother) {
      fatherShare = 1 / 3;
    } else {
      fatherShare = remainingShare;
    }

    results.push({
      id: 'father',
      relation: 'أب',
      name: heirNames['father'] || 'الأب',
      religion: 'مسلم',
      share: fatherShare,
      money: totalMoney * fatherShare,
      meters: totalMeters * fatherShare,
    });
    remainingShare -= fatherShare;
  }

  // 3. حساب نصيب الأم
  if (heirs.mother) {
    let motherShare = 0;
    const hasChildren = heirs.sons > 0 || heirs.daughters > 0;

    if (hasChildren) {
      motherShare = 1 / 6;
    } else if (heirs.father) {
      motherShare = 1 / 3;
    } else {
      motherShare = remainingShare;
    }

    results.push({
      id: 'mother',
      relation: 'أم',
      name: heirNames['mother'] || 'الأم',
      religion: 'مسلم',
      share: motherShare,
      money: totalMoney * motherShare,
      meters: totalMeters * motherShare,
    });
    remainingShare -= motherShare;
  }

  // 4. حساب نصيب الأبناء والبنات
  const hasChildren = heirs.sons > 0 || heirs.daughters > 0;
  if (hasChildren && remainingShare > 0) {
    const totalShares = heirs.sons * 2 + heirs.daughters;
    const perShare = remainingShare / totalShares;

    for (let i = 0; i < heirs.sons; i++) {
      const name = heirNames[`son-${i}`] || `الابن ${i + 1}`;
      results.push({
        id: `son-${i}`,
        relation: 'ابن',
        name,
        religion: 'مسلم',
        share: perShare * 2,
        money: totalMoney * perShare * 2,
        meters: totalMeters * perShare * 2,
      });
    }

    for (let i = 0; i < heirs.daughters; i++) {
      const name = heirNames[`daughter-${i}`] || `البنت ${i + 1}`;
      results.push({
        id: `daughter-${i}`,
        relation: 'بنت',
        name,
        religion: 'مسلم',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }
    remainingShare = 0;
  }

  // 5. حساب نصيب الأجداد والجدات (إذا لم يكن هناك أب أو أم)
  if (!heirs.father && !heirs.mother && remainingShare > 0) {
    let grandfatherShare = 0;
    let grandmotherShare = 0;

    if (heirs.paternal_grandfather && heirs.paternal_grandmother) {
      grandfatherShare = 2 / 3;
      grandmotherShare = 1 / 3;
    } else if (heirs.paternal_grandfather) {
      grandfatherShare = remainingShare;
    } else if (heirs.paternal_grandmother) {
      grandmotherShare = remainingShare;
    }

    if (heirs.paternal_grandfather) {
      results.push({
        id: 'paternal-grandfather',
        relation: 'جد أب',
        name: heirNames['paternal-grandfather'] || 'جد الأب',
        religion: 'مسلم',
        share: grandfatherShare,
        money: totalMoney * grandfatherShare,
        meters: totalMeters * grandfatherShare,
      });
      remainingShare -= grandfatherShare;
    }

    if (heirs.paternal_grandmother) {
      results.push({
        id: 'paternal-grandmother',
        relation: 'جدة أب',
        name: heirNames['paternal-grandmother'] || 'جدة الأب',
        religion: 'مسلم',
        share: grandmotherShare,
        money: totalMoney * grandmotherShare,
        meters: totalMeters * grandmotherShare,
      });
      remainingShare -= grandmotherShare;
    }
  }

  // 6. حساب نصيب الإخوة والأخوات (إذا لم يكن هناك أب)
  if (!heirs.father && heirs.full_brothers + heirs.full_sisters > 0 && remainingShare > 0) {
    const totalShares = heirs.full_brothers * 2 + heirs.full_sisters;
    const perShare = remainingShare / totalShares;

    for (let i = 0; i < heirs.full_brothers; i++) {
      const name = heirNames[`full-brother-${i}`] || `الأخ الشقيق ${i + 1}`;
      results.push({
        id: `full-brother-${i}`,
        relation: 'أخ شقيق',
        name,
        religion: 'مسلم',
        share: perShare * 2,
        money: totalMoney * perShare * 2,
        meters: totalMeters * perShare * 2,
      });
    }

    for (let i = 0; i < heirs.full_sisters; i++) {
      const name = heirNames[`full-sister-${i}`] || `الأخت الشقيقة ${i + 1}`;
      results.push({
        id: `full-sister-${i}`,
        relation: 'أخت شقيقة',
        name,
        religion: 'مسلم',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }
    remainingShare -= perShare * totalShares;
  }

  // 7. حساب نصيب الأعمام (إذا لم يكن هناك أب أو إخوة)
  if (!heirs.father && heirs.full_brothers === 0 && heirs.paternal_uncles > 0 && remainingShare > 0) {
    const perShare = remainingShare / heirs.paternal_uncles;

    for (let i = 0; i < heirs.paternal_uncles; i++) {
      const name = heirNames[`paternal-uncle-${i}`] || `العم ${i + 1}`;
      results.push({
        id: `paternal-uncle-${i}`,
        relation: 'عم',
        name,
        religion: 'مسلم',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }
    remainingShare = 0;
  }

  return results;
}

// ==================== المالكية - نظام شامل ====================
export function calculateMalikiComprehensive(input: ComprehensiveInput): Heir[] {
  // المالكية تتفق مع الحنفية في معظم الحالات
  return calculateHanafiComprehensive(input);
}

// ==================== الشافعية - نظام شامل ====================
export function calculateShafeiComprehensive(input: ComprehensiveInput): Heir[] {
  // الشافعية تتفق مع الحنفية في معظم الحالات
  return calculateHanafiComprehensive(input);
}

// ==================== الحنابلة - نظام شامل ====================
export function calculateHanbaliComprehensive(input: ComprehensiveInput): Heir[] {
  // الحنابلة تتفق مع الحنفية في معظم الحالات
  return calculateHanafiComprehensive(input);
}

// ==================== الإسماعيلية - نظام شامل ====================
export function calculateIsmailiComprehensive(input: ComprehensiveInput): Heir[] {
  const results: Heir[] = [];
  const { gender, totalMoney, totalMeters, heirs, heirNames } = input;

  let remainingShare = 1;

  // الإسماعيلية: الزوجة تأخذ 1/4 دائماً
  if (heirs.spouses > 0) {
    const spouseShare = 1 / 4;
    for (let i = 0; i < heirs.spouses; i++) {
      const name = heirNames[`spouse-${i}`] || `${gender === 'male' ? 'الزوجة' : 'الزوج'} ${i + 1}`;
      results.push({
        id: `spouse-${i}`,
        relation: gender === 'male' ? 'زوجة' : 'زوج',
        name,
        religion: 'مسلم إسماعيلي',
        share: spouseShare,
        money: totalMoney * spouseShare,
        meters: totalMeters * spouseShare,
      });
      remainingShare -= spouseShare;
    }
  }

  // الإسماعيلية: الأب والأم يأخذان 1/6 كل منهما
  if (heirs.father) {
    const fatherShare = 1 / 6;
    results.push({
      id: 'father',
      relation: 'أب',
      name: heirNames['father'] || 'الأب',
      religion: 'مسلم إسماعيلي',
      share: fatherShare,
      money: totalMoney * fatherShare,
      meters: totalMeters * fatherShare,
    });
    remainingShare -= fatherShare;
  }

  if (heirs.mother) {
    const motherShare = 1 / 6;
    results.push({
      id: 'mother',
      relation: 'أم',
      name: heirNames['mother'] || 'الأم',
      religion: 'مسلم إسماعيلي',
      share: motherShare,
      money: totalMoney * motherShare,
      meters: totalMeters * motherShare,
    });
    remainingShare -= motherShare;
  }

  // الإسماعيلية: الأبناء والبنات يرثون بالتساوي
  const hasChildren = heirs.sons > 0 || heirs.daughters > 0;
  if (hasChildren && remainingShare > 0) {
    const totalHeirs = heirs.sons + heirs.daughters;
    const perShare = remainingShare / totalHeirs;

    for (let i = 0; i < heirs.sons; i++) {
      const name = heirNames[`son-${i}`] || `الابن ${i + 1}`;
      results.push({
        id: `son-${i}`,
        relation: 'ابن',
        name,
        religion: 'مسلم إسماعيلي',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }

    for (let i = 0; i < heirs.daughters; i++) {
      const name = heirNames[`daughter-${i}`] || `البنت ${i + 1}`;
      results.push({
        id: `daughter-${i}`,
        relation: 'بنت',
        name,
        religion: 'مسلم إسماعيلي',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }
    remainingShare = 0;
  }

  return results;
}

// دالة رئيسية لاختيار المذهب المناسب
export function calculateComprehensiveInheritance(input: ComprehensiveInput): Heir[] {
  switch (input.school) {
    case 'hanafi':
      return calculateHanafiComprehensive(input);
    case 'maliki':
      return calculateMalikiComprehensive(input);
    case 'shafei':
      return calculateShafeiComprehensive(input);
    case 'hanbali':
      return calculateHanbaliComprehensive(input);
    case 'ismaili':
      return calculateIsmailiComprehensive(input);
    default:
      return calculateHanafiComprehensive(input);
  }
}
