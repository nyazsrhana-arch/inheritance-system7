/**
 * قوانين حساب المواريث حسب المذاهب الإسلامية المختلفة
 * Design: نظام الأناقة الإسلامية الحديثة - محرك الحسابات الشرعية
 */

export interface Heir {
  relation: string;
  name: string;
  religion: string;
  share: number;
  money: number;
  meters: number;
}

export interface InheritanceInput {
  gender: 'male' | 'female';
  deceasedName: string;
  totalMoney: number;
  totalMeters: number;
  partners: number;
  father: boolean;
  mother: boolean;
  sons: number;
  daughters: number;
  school: 'hanafi' | 'maliki' | 'shafei' | 'hanbali' | 'ismaili';
}

// ==================== الحنفية ====================
export function calculateHanafi(input: InheritanceInput): Heir[] {
  const results: Heir[] = [];
  const { gender, totalMoney, totalMeters, partners, father, mother, sons, daughters } = input;

  const numPartners = partners;
  const hasFather = father;
  const hasMother = mother;
  const numSons = sons;
  const numDaughters = daughters;
  const hasChildren = numSons > 0 || numDaughters > 0;

  let remainingShare = 1;

  // حساب نصيب الزوجة/الزوج
  let spouseShare = 0;
  if (numPartners > 0) {
    if (gender === 'male') {
      spouseShare = hasChildren ? 1 / 8 : 1 / 4;
    } else {
      spouseShare = 1 / 4;
    }
    for (let i = 0; i < numPartners; i++) {
      results.push({
        relation: gender === 'male' ? 'زوجة' : 'زوج',
        name: `${gender === 'male' ? 'الزوجة' : 'الزوج'} ${i + 1}`,
        religion: 'مسلم',
        share: spouseShare,
        money: totalMoney * spouseShare,
        meters: totalMeters * spouseShare,
      });
    }
    remainingShare -= spouseShare * numPartners;
  }

  // حساب نصيب الأب والأم
  if (hasFather) {
    let fatherShare = 0;
    if (hasChildren) {
      fatherShare = 1 / 6;
    } else if (hasMother) {
      fatherShare = 1 / 3;
    } else {
      fatherShare = remainingShare;
    }
    results.push({
      relation: 'أب',
      name: 'الأب',
      religion: 'مسلم',
      share: fatherShare,
      money: totalMoney * fatherShare,
      meters: totalMeters * fatherShare,
    });
    remainingShare -= fatherShare;
  }

  if (hasMother) {
    let motherShare = 0;
    if (hasChildren) {
      motherShare = 1 / 6;
    } else if (hasFather) {
      motherShare = 1 / 3;
    } else {
      motherShare = remainingShare;
    }
    results.push({
      relation: 'أم',
      name: 'الأم',
      religion: 'مسلم',
      share: motherShare,
      money: totalMoney * motherShare,
      meters: totalMeters * motherShare,
    });
    remainingShare -= motherShare;
  }

  // حساب نصيب الأبناء والبنات
  if (hasChildren && remainingShare > 0) {
    const totalShares = numSons * 2 + numDaughters;
    const perShare = remainingShare / totalShares;

    for (let i = 0; i < numSons; i++) {
      results.push({
        relation: 'ابن',
        name: `الابن ${i + 1}`,
        religion: 'مسلم',
        share: perShare * 2,
        money: totalMoney * perShare * 2,
        meters: totalMeters * perShare * 2,
      });
    }

    for (let i = 0; i < numDaughters; i++) {
      results.push({
        relation: 'بنت',
        name: `البنت ${i + 1}`,
        religion: 'مسلم',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }
  }

  return results;
}

// ==================== المالكية ====================
export function calculateMaliki(input: InheritanceInput): Heir[] {
  const results: Heir[] = [];
  const { gender, totalMoney, totalMeters, partners, father, mother, sons, daughters } = input;

  const numPartners = partners;
  const hasFather = father;
  const hasMother = mother;
  const numSons = sons;
  const numDaughters = daughters;
  const hasChildren = numSons > 0 || numDaughters > 0;

  let remainingShare = 1;

  // حساب نصيب الزوجة/الزوج (نفس الحنفية)
  let spouseShare = 0;
  if (numPartners > 0) {
    if (gender === 'male') {
      spouseShare = hasChildren ? 1 / 8 : 1 / 4;
    } else {
      spouseShare = 1 / 4;
    }
    for (let i = 0; i < numPartners; i++) {
      results.push({
        relation: gender === 'male' ? 'زوجة' : 'زوج',
        name: `${gender === 'male' ? 'الزوجة' : 'الزوج'} ${i + 1}`,
        religion: 'مسلم',
        share: spouseShare,
        money: totalMoney * spouseShare,
        meters: totalMeters * spouseShare,
      });
    }
    remainingShare -= spouseShare * numPartners;
  }

  // حساب نصيب الأب والأم (نفس الحنفية)
  if (hasFather) {
    let fatherShare = 0;
    if (hasChildren) {
      fatherShare = 1 / 6;
    } else if (hasMother) {
      fatherShare = 1 / 3;
    } else {
      fatherShare = remainingShare;
    }
    results.push({
      relation: 'أب',
      name: 'الأب',
      religion: 'مسلم',
      share: fatherShare,
      money: totalMoney * fatherShare,
      meters: totalMeters * fatherShare,
    });
    remainingShare -= fatherShare;
  }

  if (hasMother) {
    let motherShare = 0;
    if (hasChildren) {
      motherShare = 1 / 6;
    } else if (hasFather) {
      motherShare = 1 / 3;
    } else {
      motherShare = remainingShare;
    }
    results.push({
      relation: 'أم',
      name: 'الأم',
      religion: 'مسلم',
      share: motherShare,
      money: totalMoney * motherShare,
      meters: totalMeters * motherShare,
    });
    remainingShare -= motherShare;
  }

  // حساب نصيب الأبناء والبنات
  if (hasChildren && remainingShare > 0) {
    const totalShares = numSons * 2 + numDaughters;
    const perShare = remainingShare / totalShares;

    for (let i = 0; i < numSons; i++) {
      results.push({
        relation: 'ابن',
        name: `الابن ${i + 1}`,
        religion: 'مسلم',
        share: perShare * 2,
        money: totalMoney * perShare * 2,
        meters: totalMeters * perShare * 2,
      });
    }

    for (let i = 0; i < numDaughters; i++) {
      results.push({
        relation: 'بنت',
        name: `البنت ${i + 1}`,
        religion: 'مسلم',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }
  }

  return results;
}

// ==================== الشافعية ====================
export function calculateShafei(input: InheritanceInput): Heir[] {
  const results: Heir[] = [];
  const { gender, totalMoney, totalMeters, partners, father, mother, sons, daughters } = input;

  const numPartners = partners;
  const hasFather = father;
  const hasMother = mother;
  const numSons = sons;
  const numDaughters = daughters;
  const hasChildren = numSons > 0 || numDaughters > 0;

  let remainingShare = 1;

  // حساب نصيب الزوجة/الزوج
  let spouseShare = 0;
  if (numPartners > 0) {
    if (gender === 'male') {
      spouseShare = hasChildren ? 1 / 8 : 1 / 4;
    } else {
      spouseShare = 1 / 4;
    }
    for (let i = 0; i < numPartners; i++) {
      results.push({
        relation: gender === 'male' ? 'زوجة' : 'زوج',
        name: `${gender === 'male' ? 'الزوجة' : 'الزوج'} ${i + 1}`,
        religion: 'مسلم',
        share: spouseShare,
        money: totalMoney * spouseShare,
        meters: totalMeters * spouseShare,
      });
    }
    remainingShare -= spouseShare * numPartners;
  }

  // حساب نصيب الأب والأم
  if (hasFather) {
    let fatherShare = 0;
    if (hasChildren) {
      fatherShare = 1 / 6;
    } else if (hasMother) {
      fatherShare = 1 / 3;
    } else {
      fatherShare = remainingShare;
    }
    results.push({
      relation: 'أب',
      name: 'الأب',
      religion: 'مسلم',
      share: fatherShare,
      money: totalMoney * fatherShare,
      meters: totalMeters * fatherShare,
    });
    remainingShare -= fatherShare;
  }

  if (hasMother) {
    let motherShare = 0;
    if (hasChildren) {
      motherShare = 1 / 6;
    } else if (hasFather) {
      motherShare = 1 / 3;
    } else {
      motherShare = remainingShare;
    }
    results.push({
      relation: 'أم',
      name: 'الأم',
      religion: 'مسلم',
      share: motherShare,
      money: totalMoney * motherShare,
      meters: totalMeters * motherShare,
    });
    remainingShare -= motherShare;
  }

  // حساب نصيب الأبناء والبنات
  if (hasChildren && remainingShare > 0) {
    const totalShares = numSons * 2 + numDaughters;
    const perShare = remainingShare / totalShares;

    for (let i = 0; i < numSons; i++) {
      results.push({
        relation: 'ابن',
        name: `الابن ${i + 1}`,
        religion: 'مسلم',
        share: perShare * 2,
        money: totalMoney * perShare * 2,
        meters: totalMeters * perShare * 2,
      });
    }

    for (let i = 0; i < numDaughters; i++) {
      results.push({
        relation: 'بنت',
        name: `البنت ${i + 1}`,
        religion: 'مسلم',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }
  }

  return results;
}

// ==================== الحنابلة ====================
export function calculateHanbali(input: InheritanceInput): Heir[] {
  const results: Heir[] = [];
  const { gender, totalMoney, totalMeters, partners, father, mother, sons, daughters } = input;

  const numPartners = partners;
  const hasFather = father;
  const hasMother = mother;
  const numSons = sons;
  const numDaughters = daughters;
  const hasChildren = numSons > 0 || numDaughters > 0;

  let remainingShare = 1;

  // حساب نصيب الزوجة/الزوج
  let spouseShare = 0;
  if (numPartners > 0) {
    if (gender === 'male') {
      spouseShare = hasChildren ? 1 / 8 : 1 / 4;
    } else {
      spouseShare = 1 / 4;
    }
    for (let i = 0; i < numPartners; i++) {
      results.push({
        relation: gender === 'male' ? 'زوجة' : 'زوج',
        name: `${gender === 'male' ? 'الزوجة' : 'الزوج'} ${i + 1}`,
        religion: 'مسلم',
        share: spouseShare,
        money: totalMoney * spouseShare,
        meters: totalMeters * spouseShare,
      });
    }
    remainingShare -= spouseShare * numPartners;
  }

  // حساب نصيب الأب والأم
  if (hasFather) {
    let fatherShare = 0;
    if (hasChildren) {
      fatherShare = 1 / 6;
    } else if (hasMother) {
      fatherShare = 1 / 3;
    } else {
      fatherShare = remainingShare;
    }
    results.push({
      relation: 'أب',
      name: 'الأب',
      religion: 'مسلم',
      share: fatherShare,
      money: totalMoney * fatherShare,
      meters: totalMeters * fatherShare,
    });
    remainingShare -= fatherShare;
  }

  if (hasMother) {
    let motherShare = 0;
    if (hasChildren) {
      motherShare = 1 / 6;
    } else if (hasFather) {
      motherShare = 1 / 3;
    } else {
      motherShare = remainingShare;
    }
    results.push({
      relation: 'أم',
      name: 'الأم',
      religion: 'مسلم',
      share: motherShare,
      money: totalMoney * motherShare,
      meters: totalMeters * motherShare,
    });
    remainingShare -= motherShare;
  }

  // حساب نصيب الأبناء والبنات
  if (hasChildren && remainingShare > 0) {
    const totalShares = numSons * 2 + numDaughters;
    const perShare = remainingShare / totalShares;

    for (let i = 0; i < numSons; i++) {
      results.push({
        relation: 'ابن',
        name: `الابن ${i + 1}`,
        religion: 'مسلم',
        share: perShare * 2,
        money: totalMoney * perShare * 2,
        meters: totalMeters * perShare * 2,
      });
    }

    for (let i = 0; i < numDaughters; i++) {
      results.push({
        relation: 'بنت',
        name: `البنت ${i + 1}`,
        religion: 'مسلم',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }
  }

  return results;
}

// ==================== الإسماعيلية ====================
export function calculateIsmaili(input: InheritanceInput): Heir[] {
  const results: Heir[] = [];
  const { gender, totalMoney, totalMeters, partners, father, mother, sons, daughters } = input;

  const numPartners = partners;
  const hasFather = father;
  const hasMother = mother;
  const numSons = sons;
  const numDaughters = daughters;
  const hasChildren = numSons > 0 || numDaughters > 0;

  let remainingShare = 1;

  // الإسماعيلية: الزوجة تأخذ 1/4 دائماً (حتى مع الأطفال)
  let spouseShare = 0;
  if (numPartners > 0) {
    spouseShare = 1 / 4; // الزوجة تأخذ 1/4 دائماً
    for (let i = 0; i < numPartners; i++) {
      results.push({
        relation: gender === 'male' ? 'زوجة' : 'زوج',
        name: `${gender === 'male' ? 'الزوجة' : 'الزوج'} ${i + 1}`,
        religion: 'مسلم إسماعيلي',
        share: spouseShare,
        money: totalMoney * spouseShare,
        meters: totalMeters * spouseShare,
      });
    }
    remainingShare -= spouseShare * numPartners;
  }

  // الإسماعيلية: الأب والأم يأخذان 1/6 كل منهما إذا كانا موجودين
  if (hasFather) {
    const fatherShare = 1 / 6;
    results.push({
      relation: 'أب',
      name: 'الأب',
      religion: 'مسلم إسماعيلي',
      share: fatherShare,
      money: totalMoney * fatherShare,
      meters: totalMeters * fatherShare,
    });
    remainingShare -= fatherShare;
  }

  if (hasMother) {
    const motherShare = 1 / 6;
    results.push({
      relation: 'أم',
      name: 'الأم',
      religion: 'مسلم إسماعيلي',
      share: motherShare,
      money: totalMoney * motherShare,
      meters: totalMeters * motherShare,
    });
    remainingShare -= motherShare;
  }

  // الإسماعيلية: الأبناء والبنات يرثون بالتساوي (الابن والبنت متساويان)
  if (hasChildren && remainingShare > 0) {
    const totalHeirs = numSons + numDaughters;
    const perShare = remainingShare / totalHeirs;

    for (let i = 0; i < numSons; i++) {
      results.push({
        relation: 'ابن',
        name: `الابن ${i + 1}`,
        religion: 'مسلم إسماعيلي',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }

    for (let i = 0; i < numDaughters; i++) {
      results.push({
        relation: 'بنت',
        name: `البنت ${i + 1}`,
        religion: 'مسلم إسماعيلي',
        share: perShare,
        money: totalMoney * perShare,
        meters: totalMeters * perShare,
      });
    }
  }

  return results;
}

// دالة رئيسية لاختيار المذهب المناسب
export function calculateInheritance(input: InheritanceInput): Heir[] {
  switch (input.school) {
    case 'hanafi':
      return calculateHanafi(input);
    case 'maliki':
      return calculateMaliki(input);
    case 'shafei':
      return calculateShafei(input);
    case 'hanbali':
      return calculateHanbali(input);
    case 'ismaili':
      return calculateIsmaili(input);
    default:
      return calculateHanafi(input);
  }
}
