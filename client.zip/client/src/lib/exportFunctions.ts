/**
 * دوال تصدير نتائج حساب الميراث إلى PDF و Excel
 * Design: نظام الأناقة الإسلامية الحديثة - ميزات التصدير
 */

import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import type { Heir } from './inheritanceCalculations';

const schoolNames: Record<string, string> = {
  hanafi: 'الحنفية',
  maliki: 'المالكية',
  shafei: 'الشافعية',
  hanbali: 'الحنابلة',
  ismaili: 'الإسماعيلية',
};

export interface ExportData {
  deceasedName: string;
  school: string;
  totalMoney: number;
  totalMeters: number;
  heirs: Heir[];
  exportDate: string;
}

/**
 * تصدير النتائج إلى ملف PDF
 */
export function exportToPDF(data: ExportData) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // تعيين الخط العربي
  doc.setFont('Arial', 'normal');
  
  // العنوان الرئيسي
  doc.setFontSize(18);
  doc.setTextColor(27, 94, 32); // أخضر داكن
  doc.text('نظام تقسيم الميراث الشرعي', 105, 20, { align: 'center' });

  // معلومات المتوفى
  doc.setFontSize(12);
  doc.setTextColor(0, 0, 0);
  doc.text(`اسم المتوفى: ${data.deceasedName}`, 20, 35);
  doc.text(`المذهب الشرعي: ${schoolNames[data.school] || data.school}`, 20, 42);
  doc.text(`تاريخ الحساب: ${data.exportDate}`, 20, 49);
  doc.text(`مبلغ التركة: ${data.totalMoney.toFixed(2)} ريال`, 20, 56);
  doc.text(`إجمالي الأمتار: ${data.totalMeters.toFixed(2)} متر`, 20, 63);

  // جدول النتائج
  const tableData = data.heirs.map((heir) => [
    heir.relation,
    heir.name,
    `${(heir.share * 100).toFixed(2)}%`,
    heir.money.toFixed(2),
    heir.meters.toFixed(2),
  ]);

  const headers = ['الصلة', 'الاسم', 'النسبة', 'المال (ريال)', 'المتر'];

  // استخدام autoTable للجدول
  (doc as any).autoTable({
    head: [headers],
    body: tableData,
    startY: 75,
    margin: { left: 20, right: 20 },
    styles: {
      font: 'Arial',
      fontSize: 10,
      textColor: [0, 0, 0],
      halign: 'center',
      valign: 'middle',
    },
    headStyles: {
      fillColor: [27, 94, 32], // أخضر داكن
      textColor: [255, 255, 255],
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: [241, 245, 244], // أخضر فاتح جداً
    },
    columnStyles: {
      0: { halign: 'right' },
      1: { halign: 'right' },
      2: { halign: 'center' },
      3: { halign: 'center' },
      4: { halign: 'center' },
    },
  });

  // الملاحظات في الأسفل
  const finalY = (doc as any).lastAutoTable.finalY || 200;
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text('ملاحظة: هذا الحساب تقريبي ويجب مراجعة متخصص شرعي للتأكد من الدقة.', 20, finalY + 15);

  // حفظ الملف
  doc.save(`ميراث_${data.deceasedName || 'المتوفى'}_${new Date().getTime()}.pdf`);
}

/**
 * تصدير النتائج إلى ملف Excel
 */
export function exportToExcel(data: ExportData) {
  // إنشاء workbook جديد
  const workbook = XLSX.utils.book_new();

  // إنشاء ورقة البيانات الأساسية
  const summaryData = [
    ['نظام تقسيم الميراث الشرعي'],
    [],
    ['اسم المتوفى', data.deceasedName],
    ['المذهب الشرعي', schoolNames[data.school] || data.school],
    ['تاريخ الحساب', data.exportDate],
    ['مبلغ التركة (ريال)', data.totalMoney],
    ['إجمالي الأمتار', data.totalMeters],
    [],
  ];

  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  summarySheet['!cols'] = [{ wch: 25 }, { wch: 25 }];
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'ملخص');

  // إنشاء ورقة تفاصيل الورثة
  const heirsData = [
    ['الصلة', 'الاسم', 'النسبة (%)', 'المال (ريال)', 'المتر'],
    ...data.heirs.map((heir) => [
      heir.relation,
      heir.name,
      (heir.share * 100).toFixed(2),
      heir.money.toFixed(2),
      heir.meters.toFixed(2),
    ]),
  ];

  const heirsSheet = XLSX.utils.aoa_to_sheet(heirsData);
  heirsSheet['!cols'] = [
    { wch: 15 },
    { wch: 20 },
    { wch: 15 },
    { wch: 20 },
    { wch: 15 },
  ];

  // تنسيق رأس الجدول
  const headerStyle = {
    font: { bold: true, color: { rgb: 'FFFFFFFF' } },
    fill: { fgColor: { rgb: '1B5E20' } },
    alignment: { horizontal: 'center', vertical: 'center' },
  };

  for (let i = 0; i < 5; i++) {
    const cellRef = XLSX.utils.encode_cell({ r: 0, c: i });
    if (heirsSheet[cellRef]) {
      heirsSheet[cellRef].s = headerStyle;
    }
  }

  XLSX.utils.book_append_sheet(workbook, heirsSheet, 'الورثة');

  // حفظ الملف
  XLSX.writeFile(workbook, `ميراث_${data.deceasedName || 'المتوفى'}_${new Date().getTime()}.xlsx`);
}

/**
 * تصدير النتائج إلى ملف CSV
 */
export function exportToCSV(data: ExportData) {
  let csvContent = 'data:text/csv;charset=utf-8,\uFEFF'; // BOM للدعم الكامل للعربية

  // رأس الملف
  csvContent += 'نظام تقسيم الميراث الشرعي\n';
  csvContent += `اسم المتوفى,${data.deceasedName}\n`;
  csvContent += `المذهب الشرعي,${schoolNames[data.school] || data.school}\n`;
  csvContent += `تاريخ الحساب,${data.exportDate}\n`;
  csvContent += `مبلغ التركة (ريال),${data.totalMoney}\n`;
  csvContent += `إجمالي الأمتار,${data.totalMeters}\n`;
  csvContent += '\n';

  // رأس الجدول
  csvContent += 'الصلة,الاسم,النسبة (%),المال (ريال),المتر\n';

  // بيانات الورثة
  data.heirs.forEach((heir) => {
    csvContent += `${heir.relation},${heir.name},${(heir.share * 100).toFixed(2)},${heir.money.toFixed(2)},${heir.meters.toFixed(2)}\n`;
  });

  // إنشاء رابط التحميل
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `ميراث_${data.deceasedName || 'المتوفى'}_${new Date().getTime()}.csv`);
  document.body.appendChild(link);

  // تنزيل الملف
  link.click();

  // إزالة الرابط
  document.body.removeChild(link);
}
